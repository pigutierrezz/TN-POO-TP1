package ar.org.centro8.java.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TnPooTp1Application {

	public static void main(String[] args) {
		SpringApplication.run(TnPooTp1Application.class, args);
	}

}
