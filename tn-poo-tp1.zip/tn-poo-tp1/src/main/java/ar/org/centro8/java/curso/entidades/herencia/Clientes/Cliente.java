package ar.org.centro8.java.curso.entidades.herencia.Clientes;

import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;

@Getter
@Setter
@AllArgsConstructor
public abstract class Cliente {
    private int numeroCliente;
}